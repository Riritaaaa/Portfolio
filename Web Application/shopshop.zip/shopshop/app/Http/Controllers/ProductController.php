<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Product;
use App\Models\ProductType;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $products = Product::all();
        $carts=Cart::where('user_id',1)->get();
        return view('product.index', compact('products','carts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $ptypes = ProductType::all();
        return view('product.create')->with('ptypes', $ptypes);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $p = new Product();
        $p->name = $request->name;
        $p->price = $request->price;
        $p->qty = $request->qty;
        $p->cost = $request->cost;
        $p->product_type_id = $request->product_type_id;
        $p->save();

        return redirect()->route('products.index')->with('status','บันทึกข้อมูลสำเร็จ');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
        Product::destroy($id);
        return back();
    }
    public function remove_from_cart($product_id)
    {
        $user_id = 1;
        $cart = Cart::where('user_id', $user_id)->where('product_id', $product_id)->first();
        if($cart!=null){
            $cart->qty-=1;
            $cart->save();
        }

        return redirect()->route('products.index')->with('status','ลบสินค้าสำเร็จ');
    }
    public function  add_to_cart($product_id)
    {
        $user_id = 1;
        //find item
        $cart = Cart::where('user_id',$user_id)->where('product_id',$product_id)->first();
        if($cart ==null){
            $cart= new Cart();
            $cart->qty=0;
        }
        $cart->product_id = $product_id;
        $cart->user_id = $user_id;
        $cart->qty+=1;
        $cart->save();

        return redirect()->route('products.index')->with('status','เพิ่มสินค้าลงตะกร้าสำเร็จ');
    }

    public function empty_cart()
    {
        $user_id = 1;
        Cart::where('user_id',$user_id)->delete();
        return redirect()->route('products.index')->with('status','ล้างตะกร้าสำเร็จ');
    }
}
