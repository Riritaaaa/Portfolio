<?php $__env->startSection('content'); ?>
    <h1>เกี่ยวกับร้าน ชอบช้อป</h1>
<ul>
    <li>เจ้าของร้าน : <?php echo e($name); ?></li>
    <li>เบอร์โทรศัพท์ : <?php echo e($phone); ?></li>
    <li>ที่ตั้งร้าน : <?php echo e($address); ?></li>
</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\shopshop\resources\views/myshop.blade.php ENDPATH**/ ?>