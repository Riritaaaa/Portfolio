<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if(session('status')): ?>
                <div class="row">
                    <div class="col">
                        <div class="alert alert-success text-white" role="alert">
                            <strong>Success!</strong> <?php echo e(session('status')); ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <div
                    <?php if(count($carts)>0): ?>
                        class="col-8"
                    <?php else: ?>
                        class="col-12"
                    <?php endif; ?>>
            <div class="card mb-4">
                <div class="card-header pb-0">
                    <h6>สินค้าของเรา (<?php echo e($products->count()); ?> รายการ)</h6>
                </div>
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0">
                            <thead>
                            <tr>

                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ชื่อ
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                    ราคา
                                </th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">จ
                                    านวนคงเหลือ
                                </th>
                                <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                    เครื่องมือ
                                </th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <p class="text-xs px-4 font-weight-bold mb-0"><?php echo e($product->id); ?></p>
                                </td>
                                <td>
                                    <div class="d-flex px-2 py-1">
                                        <div>
                                            <div>
                                                <img src="<?php echo e($product->image_url == '' ? '/assets/img/box.png' : $product->image_url); ?>"  class="avatar avatar-sm me-3" alt="user1">
                                            </div>

                                        </div>
                                        <div class="d-flex flex-column justify-content-center">
                                            <h6 class="mb-0 text-sm"><?php echo e($product->name); ?></h6>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($product->productType->name); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p class="text-xs font-weight-bold mb-0"><?php echo e($product->price); ?></p>
                                    <p class="text-xs text-secondary mb-0">บาท</p>
                                </td>
                                <td>
                                    <p class="text-xs font-weight-bold mb-0"><?php echo e($product->qty); ?></p>
                                    <p class="text-xs text-secondary mb-0">ชิ้น</p>
                                </td>
                                <td class="align-middle">
                                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <a href="#" class="btn btn-outline-success px-3 py-2"><i
                                                class="fa fa-pencil"></i> แก้ไข</a>
                                        <button type="submit" class="btn btn-outline-danger px-3 py-2"
                                                onclick="return confirm('คุณต้องการลบข้อมูลหรือไม่?')"> ลบ
                                        </button>
                                        <a href="<?php echo e(route('add_to_cart',$product->id)); ?>" class="btn btn-outline-danger px-3 py-2">
                                            หยิบใส่ตะกร้า
                                        </a>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
                <?php echo $__env->make('product.cart', ['carts'=>$carts], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\web\shopshop\resources\views/product/index.blade.php ENDPATH**/ ?>