var btn_open = document.getElementById('search-btn');
var form = document.getElementById('form');
var menu = document.getElementById('menu');
var navBtn = document.getElementById('nav-btn');
var nav = document.getElementById('nav');


btn_open.addEventListener('click', function () {
    if(form.style.display === 'none'){
        form.style.display = 'block';
    }
    else {
        form.style.display = 'none';
    }
})


navBtn.addEventListener('click', function () {
    if(menu.style.display === 'none'){
        menu.style.display = 'flex';
        
    }
    else{
        menu.style.display = 'none';
    }
})


function closeMenu(){
    menu.style.display = 'none';
}


let mybutton = document.getElementById("myBtn");
window.onscroll = function () { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
    } else {
        mybutton.style.display = "none";
    }
}
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}


function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("default").click();