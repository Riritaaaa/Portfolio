$(document).ready(function(){
    $('.banner').slick({
        autoplay: true
    });
    $('.slick-prev').html('<i class="fa-solid fa-chevron-left"></i>');
    $('.slick-next').html('<i class="fa-solid fa-chevron-right"></i>');
})

