package test8_2_Topdown;

import main.LiquidConverter;

public class LiquidMulti_Stub extends LiquidConverter {
	//Convert from cup to ml
	@Override
	public double getMultiplier(String fromUnit, String toUnit) {
		return 250.0;
	}
}