package test8_2_Topdown;

import main.ButterConverter;

public class ButterMulti_Stub extends ButterConverter {
	//Convert from cup to gram
		@Override
		public double getMultiplier(String fromUnit, String toUnit) {
			return 227.0;
		}
}
