package test8_2_Topdown;

import main.FlourConverter;

public class FlourConvert_Stub extends FlourConverter {
	//Convert from cup to gram
	@Override
	public double convert(double flourValue, String fromUnit, String toUnit) {
		return 250.0;
	}
}