package test8_2_Topdown;

import main.IngredientConverter;

public class IngredientConvert_Driver {
	public static void main(String[] args)
	{
		double originalValue = 1.0;
		double convertedValue = 0.0;	
		String selectedChoiceButter = "butter";
		String fromCup = "cup";
		String toGram = "gram";
		
		IngredientConverter converter = new IngredientConverter();
		
		convertedValue = converter.convert(originalValue, selectedChoiceButter, fromCup, toGram);
		System.out.println(originalValue + " " + fromCup + " = " + convertedValue + " " + toGram);
		
		
		String selectedChoiceFlour = "flour";
		convertedValue = converter.convert(originalValue, selectedChoiceFlour, fromCup, toGram);
		System.out.println(originalValue + " " + fromCup + " = " + convertedValue + " " + toGram);
		
		
		String selectedChoiceLiquid = "liquid";
		String toMl = "ml";
		convertedValue = converter.convert(originalValue, selectedChoiceLiquid, fromCup, toMl);
		System.out.println(originalValue + " " + fromCup + " = " + convertedValue + " " + toMl);
		
	}
}
