package test8_2_Topdown;

import main.FlourConverter;

public class FlourMulti_Stub extends FlourConverter{
	//Convert from cup to gram
		@Override
		public double getMultiplier(String fromUnit, String toUnit) {
			return 125.0;
		}
}
