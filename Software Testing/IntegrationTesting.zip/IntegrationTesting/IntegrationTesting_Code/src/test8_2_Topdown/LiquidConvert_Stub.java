package test8_2_Topdown;

import main.LiquidConverter;

public class LiquidConvert_Stub extends LiquidConverter {
	//Convert from cup to gram
	@Override
	public double convert(double flourValue, String fromUnit, String toUnit) {
		return 500.0;
	}
}
