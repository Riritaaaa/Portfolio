package test8_2_Topdown;

import main.ButterConverter;

public class ButterConvert_Stub extends ButterConverter {
	//Convert from cup to gram
	@Override
	public double convert(double flourValue, String fromUnit, String toUnit) {
		return 454.0;
	}
}
