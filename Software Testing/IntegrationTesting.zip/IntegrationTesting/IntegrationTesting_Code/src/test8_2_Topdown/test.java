package test8_2_Topdown;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class test {

	@Test
	@DisplayName("TC01 : Test Butter Stub")
	void TC01() {
		ButterConvert_Stub butterconvert_stub = new ButterConvert_Stub();
		double expectedResult = 454.0;
		assertEquals(expectedResult, butterconvert_stub.convert(2, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC02 : Test Flour Stub")
	void TC02() {
		FlourConvert_Stub flourconvert_stub = new FlourConvert_Stub();
		double expectedResult = 250.0;
		assertEquals(expectedResult, flourconvert_stub.convert(2, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC03 : Test Liquid Stub")
	void TC03() {
		LiquidConvert_Stub liquidconvert_stub = new LiquidConvert_Stub();
		double expectedResult = 500.0;
		assertEquals(expectedResult, liquidconvert_stub.convert(2, "cup", "ml"));
	}
	
	@Test
	@DisplayName("TC04 : Test Butter Multi Stub")
	void TC04() {
		ButterMulti_Stub buttermulti_stub = new ButterMulti_Stub();
		double expectedResult = 227.0;
		assertEquals(expectedResult, buttermulti_stub.convert(1, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC05 : Test Flour Multi Stub")
	void TC05() {
		FlourMulti_Stub flourmulti_stub = new FlourMulti_Stub();
		double expectedResult = 125.0;
		assertEquals(expectedResult, flourmulti_stub.convert(1, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC06 : Test Liquid Multi Stub")
	void TC06() {
		LiquidMulti_Stub liquidmulti_stub = new LiquidMulti_Stub();
		double expectedResult = 250.0;
		assertEquals(expectedResult, liquidmulti_stub.convert(1, "cup", "ml"));
	}

}