package test8_3_Bottomup;

import main.ButterConverter;

public class ButterConvert_Multi extends ButterConverter {
	//Convert from cup to gram
	@Override
	public double getMultiplier(String fromUnit, String toUnit) {
		return 227.0;
	} 

}
