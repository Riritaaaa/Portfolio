package test8_3_Bottomup;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ButterConverter;
import main.FlourConverter;
import main.LiquidConverter;

class testbottomup {

	@Test
	@DisplayName("TC01 : Test Butter Convert + Butter Multi")
	void TC01() {
		ButterConverter buttercon = new ButterConverter();
		double expectedResult = 227.0;
		assertEquals(expectedResult, buttercon.convert(1, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC02 : Test Flour Convert + Flour Multi")
	void TC02() {
		FlourConverter flourcon = new FlourConverter();
		double expectedResult = 125.0;
		assertEquals(expectedResult, flourcon.convert(1, "cup", "gram"));
	}
	
	@Test
	@DisplayName("TC03 : Test Liquid Convert + Liquid Multi")
	void TC03() {
		LiquidConverter liquidcon = new LiquidConverter();
		double expectedResult = 250.0;
		assertEquals(expectedResult, liquidcon.convert(1, "cup", "ml"));
	}
	
}
