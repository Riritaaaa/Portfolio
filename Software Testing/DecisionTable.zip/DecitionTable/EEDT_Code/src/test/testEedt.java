package test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import main.Converter;

class testEedt {
	
	String SizeInKilo;
	Converter converter;
	
	@ParameterizedTest
	@CsvFileSource(files = "src/test/resource/eedt.csv")
	@DisplayName("TestEEDT Tested by 643020488-2")
		void test(boolean intflight, int flightclass, int royalty, String expected) {
			converter = new Converter(intflight, royalty, royalty);
			SizeInKilo = converter.showResult(converter.convert());
			assertEquals(expected,SizeInKilo);
	}
}
