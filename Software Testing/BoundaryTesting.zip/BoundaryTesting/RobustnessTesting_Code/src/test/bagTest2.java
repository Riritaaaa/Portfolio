package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;


class bagTest2 {

	//Robustness valid and invalid
	@ParameterizedTest
	@CsvSource({
		 //valid
	     "false, 1, 2",
	     "false, 2, 2",
	     "false, 3, 2",
	     "false, 2, 0",
	     "false, 2, 1",
	     "false, 2, 3",
	     
	     //invalid
	     "false, 0, 2",
	     "false, 4, 0",
	     "false, 2, -1",
	     "false, 2, 4",
	     
	     //valid
	     "true, 1, 2",
	     "true, 2, 2",
	     "true, 3, 2",
	     "true, 2, 0",
	     "true, 2, 1",
	     "true, 2, 3",
	     
	     //invalid
	     "true, 0, 2",
	     "true, 4, 0",
	     "true, 2, -1",
	     "true, 2, 4"
	    
	 })
	@DisplayName("TestCsvSource " + "Tested by 643020488-2")
	void test(boolean intflight, int flightclass, int royalty) {
		assertNotNull(intflight);
		assertFalse(flightclass < 1 || flightclass > 3);
		assertFalse(royalty < 0 || royalty > 3);
	}
	
	
	
	
	
	
}
	