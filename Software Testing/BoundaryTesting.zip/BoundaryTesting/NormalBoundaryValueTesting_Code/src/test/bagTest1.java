package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.Converter;

class bagTest1 {

	Converter converter;
	String SizeInKilo;

	//normal boundary only valid 
	@Test
	@DisplayName("TC01 : Domestic(false), firstclass(1), gold(2) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC01() {
		converter = new Converter(false, 1, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC02 : Domestic(false), bussinessclass(2), gold(2) = 32 kg (L) " + "Tested by 643020488-2")
	void test_TC02() {
		converter = new Converter(false, 2, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("32 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC03 : Domestic(false), economy(3), gold(2) = 23 kg (S) " + "Tested by 643020488-2")
	void test_TC03() {
		converter = new Converter(false, 3, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("23 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC04 : Domestic(false), bussinessclass(2), not mem(0) = 15 kg (S) " + "Tested by 643020488-2")
	void test_TC04() {
		converter = new Converter(false, 2, 0);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("15 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC05 : Domestic(false), bussinessclass(2), platinum(1) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC05() {
		converter = new Converter(false, 2, 1);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC06 : Domestic(false), bussinessclass(2), silver(3) = 23 kg (M) " + "Tested by 643020488-2")
	void test_TC06() {
		converter = new Converter(false, 2, 3);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("23 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC07 : Internatoinal(true), firstclass(1), gold(2) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC07() {
		converter = new Converter(true, 1, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC08 : Internatoinal(true),  bussinessclass(2), gold(2) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC08() {
		converter = new Converter(true, 2, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC09 : Internatoinal(true), economy(3), gold(2) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC09() {
		converter = new Converter(true, 3, 2);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC10 : Internatoinal(true), bussinessclass(2), not mem(0) = 32 kg (L) " + "Tested by 643020488-2")
	void test_TC10() {
		converter = new Converter(true, 2, 0);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("32 kg", SizeInKilo);
	}
	
	@Test
	@DisplayName("TC11 : Internatoinal(true), bussinessclass(2), platinum(1) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC11() {
		converter = new Converter(true, 2, 1);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}

	@Test
	@DisplayName("TC12 : Internatoinal(true), bussinessclass(2), silver(3) = 40 kg (XL) " + "Tested by 643020488-2")
	void test_TC12() {
		converter = new Converter(true, 2, 3);
		SizeInKilo = converter.showResult(converter.convert());
		assertEquals("40 kg", SizeInKilo);
	}
	
}
