package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

class bagTest3 {

	//Worst case boundary
	@ParameterizedTest
	@CsvFileSource(files = "src/test/resources/weight.csv")
	@DisplayName("TestCsvFileSource " + "Tested by 643020488-2")
		void test(boolean intflight, int flightclass, int royalty) {
			assertNotNull(intflight);
			assertFalse(flightclass < 1 || flightclass > 3);
			assertFalse(royalty < 0 || royalty > 3);
	}
	
}
