package test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


import main.CountClump;

class counttest {
	
	CountClump countclump;
	int countClumps;
	
	@BeforeEach
	void setUp() throws Exception {
		this.countclump = new CountClump();
	}
	
	@Test
	@DisplayName("TC01: {} Tested by 643020488-2")
	void TC01() {
		int nums[] = {};
		this.countClumps = CountClump.countClumps(nums);
		assertEquals(0,this.countClumps);
	}
	
	@Test
	@DisplayName("TC02: {1,1,3,1,1} Tested by 643020488-2")
	void TC02() {
		int nums[] = {1,1,3,1,1};
		this.countClumps = CountClump.countClumps(nums);
		assertEquals(2,this.countClumps);
	}
	
	@Test
	@DisplayName("TC03: {1,1,1,1,1} Tested by 643020488-2")
	void TC03() {
		int nums[] = {1,1,1,1,1};
		this.countClumps = CountClump.countClumps(nums);
		assertEquals(1,this.countClumps);
	}
	
	@Test
	@DisplayName("TC04: { } Tested by 643020488-2")
	void TC04() {
		int nums[] = { };
		this.countClumps = CountClump.countClumps(nums);
		assertEquals(0,this.countClumps);
	}

}
